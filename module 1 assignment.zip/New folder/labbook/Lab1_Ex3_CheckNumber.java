package capgemini.labbook;

public class Lab1_Ex3_CheckNumber {
	
	public static boolean checkNumber(int a) {
		int x = a%10 , y = (a%100)/10;
		a = a/10;
		while(a!=0){
			 if(x<y){
				 return false;
			 }
			 x = a%10;
			 y = (a%100)/10;
			 a = a/10;
		}
		return true;
	}
	
	public static void main(String[] args) {
		int n = 54321;
		boolean result;
		result = checkNumber(n);
		if(result){
			System.out.println("The given number is : True");
		}
		else{
			System.out.println("The given number is : False");
		}
	}
}
