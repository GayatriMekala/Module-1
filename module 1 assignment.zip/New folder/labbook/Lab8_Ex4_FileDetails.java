package capgemini.labbook;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_FileDetails {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter file path :(Ex: C:\\kesava\\FileLineNumbers.txt)");
		String fileName = scan.next();
		File file = new File(fileName);
		System.out.println("File " + (file.exists() ? "exists" : "Not exists"));
		System.out.println("File is " + (file.canRead() ? "Readable" : "Not Readable"));
		System.out.println("File is " + (file.canWrite() ? "Writable" : "Not Writable"));
		System.out.println("File " + (file.isFile() ? "File" : "Directory"));
		System.out.println("File size " + file.length() + " Bytes");
		scan.close();
	}

}