package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex3_PrimeNumbers {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a range :");
		int n = scan.nextInt();
		for (int i = 1; i < n; i++) {
			// System.out.println(i);
			int j;
			for (j = 2; j <= Math.sqrt(i); j++) {
				// System.out.println(i + "%" + j + " = " + i % j);
				if (i % j == 0)
					break;
			}
			if (j > Math.sqrt(i))
				System.out.print(i + " ");
		}
		scan.close();
	}

}