package capgemini.labbook;

import java.util.Arrays;

public class Lab3_Ex3_GetSorted {
	public static int[] getSorted(int[] nums) {
		for (int i = 0; i < nums.length; i++) {
			StringBuffer s = new StringBuffer(Integer.toString(nums[i]));
			nums[i] = Integer.parseInt(s.reverse().toString());
		}
		Arrays.sort(nums);
		return nums;
	}

	public static void main(String[] args) {
		int[] nums = { 12, 102, 58, 65, 72 };
		int[] Nums = getSorted(nums);
		for (int i = 0; i < nums.length; i++) {
			System.out.println(+Nums[i]);
		}
	}
}
