package capgemini.labbook;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public class Lab11_Ex1_MultiThreading implements Callable<String> {
	private FileInputStream inStream;
	private FileOutputStream outStream;

	public Lab11_Ex1_MultiThreading(FileInputStream inStream, FileOutputStream outStream) {
		super();
		this.inStream = inStream;
		this.outStream = outStream;
	}

	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub

		BufferedInputStream bufferedInputStream = new BufferedInputStream(inStream, 10);
		BufferedOutputStream outputStream = new BufferedOutputStream(outStream, 10);
		byte[] b = new byte[10];

		while (bufferedInputStream.read(b, 0, 10) != -1) {
			// System.out.println(Arrays.toString(b));
			// System.out.println("10 characters written into file");
			TimeUnit.SECONDS.sleep(5);
			outputStream.write(b);
		}
		return "Copy completed";
	}

}