package capgemini.labbook;

public class Lab1_Ex2_CalculateDifference {
	
	public static int sns(int num) {
		int result=0;
		for(int i=0;i<=num;i++){
			result = result + (i*i); 
		}
		return result;
	}
	
	public static int ssn(int num) {
		int result=0;
		for(int i=0;i<=num;i++){
			result = result + i; 
		}
		return result*result;
	}
	
	public static int calculateDifference(int num) {
		int x = sns(num)-ssn(num);
		return x;
		
	}
	public static void main(String[] args) {
		int y;
		y = calculateDifference(3);
		System.out.println("ResultL: " +y);
	}
}
